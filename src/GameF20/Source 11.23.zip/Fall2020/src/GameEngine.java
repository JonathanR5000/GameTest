import java.awt.*;
import java.awt.event.*;

import java.util.*;

import javax.swing.ImageIcon;

public class GameEngine extends GameApplet{
	
	
	long lastEnemyKilled;
	
    //implementing 2D arrays
  	int row = 11;	
  	int col = 30;
  	
	// Preparing the background image
	String backgroundPath = "purple.png";
	Image background = Toolkit.getDefaultToolkit().getImage(backgroundPath);
	
	// Player object
	Spaceship spaceship = new Spaceship(848, 700, "blue2");
		
	//collision detection variables
	int ssh = spaceship.height;
	int ssw = spaceship.width;
	double ssx = spaceship.x;
	double ssy = spaceship.y;
	


	int current = spaceship.currentShip;
	
	//3 lines for space ship 1
		Line ss1l1 = new Line(ssx,ssy+0.7*ssh,ssx+(ssw/2)-8 ,ssy);
		Line ss1l2 = new Line(ssx+(ssw/2)-8,ssy, ssx+(ssw/2)+8,ssy );
		Line ss1l3 = new Line(ssx+(ssw/2)+8 ,ssy,ssx+ssw, ssy+0.7*ssh);
		//======================================================================================
	
	
	//3 lines for space ship 2
	Line ss2l1 = new Line(ssx,ssy+0.6*ssh,ssx+(ssw/2)-5 ,ssy);
	Line ss2l2 = new Line(ssx+(ssw/2)-5,ssy, ssx+(ssw/2)+5,ssy );
	Line ss2l3 = new Line(ssx+(ssw/2)+5 ,ssy,ssx+ssw, ssy+0.6*ssh);
	//======================================================================================
	//3 lines for space ship 3
	
	Line ss3l1 = new Line(ssx,ssy+0.8*ssh,ssx+(ssw/2)-5 ,ssy);
	Line ss3l2 = new Line(ssx+(ssw/2)-5,ssy, ssx+(ssw/2)+5,ssy );
	Line ss3l3 = new Line(ssx+(ssw/2)+5 ,ssy,ssx+ssw, ssy+0.8*ssh);

	
	//======================================================================================
	
	//works for All spaceships - 
	
	Line ssAl1 = new Line(-1,-1,-2,-2);
	Line ssAl2 = new Line(-1,-1,-2,-2);
	Line ssAl3 = new Line(-1,-1,-2,-2);
	
	//reassigns lines to general variable
	
	

//	if (this.current==0 || current==3 || current==6 || current==9) {     
//		ssAl1=ss1l1;	
//	}
//		
		
//		
//	if (current==1 || current==4 || current==7 || current==10) { 
//		ssAl1=ss1l1;	
//
//	}
//			
//			
//			
//	if (current==2 || current==5 || current==8 || current==11) {
//		ssAl1=ss1l1;	
//
//	}
	
	
	
	//======================================================================================

	//ENEMY ammunition
	LaserEnemyShip[] enemyLasersArr; 
	
	
	/*/
	// Enemy objects
	UFO ufo = new UFO(300, 200, "blue");
	UFO ufo2 = new UFO(600, 100, "yellow");
	UFO ufo3 = new UFO(0, 300, "green");
	UFO ufo4 = new UFO(800, 200, "red");
	UFO ufo5 = new UFO(1100, 100, "blue");
	//*/
	
	EnemyShip[] enemies = new EnemyShip[11];

	//Ammunition
	Laser[] lasers = new Laser[20];
	
	int enemyBulletCount=30;  //
	LaserEnemyShip[] enemyLasers   = new LaserEnemyShip[enemyBulletCount];
	LaserEnemyShip[] enemyLasers1  = new LaserEnemyShip[enemyBulletCount];
	LaserEnemyShip[] enemyLasers2  = new LaserEnemyShip[enemyBulletCount];
	LaserEnemyShip[] enemyLasers3  = new LaserEnemyShip[enemyBulletCount];
	LaserEnemyShip[] enemyLasers4  = new LaserEnemyShip[enemyBulletCount];
	LaserEnemyShip[] enemyLasers5  = new LaserEnemyShip[enemyBulletCount];
	LaserEnemyShip[] enemyLasers6  = new LaserEnemyShip[enemyBulletCount];
	LaserEnemyShip[] enemyLasers7  = new LaserEnemyShip[enemyBulletCount];
	LaserEnemyShip[] enemyLasers8  = new LaserEnemyShip[enemyBulletCount];
	LaserEnemyShip[] enemyLasers9  = new LaserEnemyShip[enemyBulletCount];
	LaserEnemyShip[] enemyLasers10 = new LaserEnemyShip[enemyBulletCount];
	//LaserEnemyShip[] enemyLasers11 = new LaserEnemyShip[30];

	

	//2d array   
	//this replaces the block of code above
	LaserEnemyShip [][] enemyLaser2D = new LaserEnemyShip[row][col];// row=11 and col=30

	//loop through entire 2d array, Stop by each row, then loop through all columns then go to next row
	
	
	

	
	//need to delete this circle Array
	//Circle [] circleBullet = new Circle [100];


	   //=======================================================================================

	
   //=======================================================================================
	
	public void init() {
		
	
		
		// The loop creates all of the lasers
		for(int i = 0; i < lasers.length; i++) {
			lasers[i] = new Laser(-20000, -20000, 5);
		}
		
		
		// This loop creates the enemy lasers
		int enemyLaserSpeed = 6;

		for(int i = 0; i < enemyLasers.length; i++) {
			enemyLasers[i]  = new LaserEnemyShip(-30000, -30000, enemyLaserSpeed);
			enemyLasers1[i]  = new LaserEnemyShip(-30000, -30000, enemyLaserSpeed);
			enemyLasers2[i]  = new LaserEnemyShip(-30000, -30000, enemyLaserSpeed);
			enemyLasers3[i]  = new LaserEnemyShip(-30000, -30000, enemyLaserSpeed);
			enemyLasers4[i]  = new LaserEnemyShip(-30000, -30000, enemyLaserSpeed);
			enemyLasers5[i]  = new LaserEnemyShip(-30000, -30000, enemyLaserSpeed);
			enemyLasers6[i]  = new LaserEnemyShip(-30000, -30000, enemyLaserSpeed);
			enemyLasers7[i]  = new LaserEnemyShip(-30000, -30000, enemyLaserSpeed);
			enemyLasers8[i]  = new LaserEnemyShip(-30000, -30000, enemyLaserSpeed);
			enemyLasers9[i]  = new LaserEnemyShip(-30000, -30000, enemyLaserSpeed);
			enemyLasers10[i] = new LaserEnemyShip(-30000, -30000, enemyLaserSpeed);
			//enemyLasers11[i] = new LaserEnemyShip(-30000, -30000, 6);
			}
		
		/*/
		//this code replaces the block above
	
	 for (int i=0;i<=row;i++){
			for(int j = 0; j <= col; j++){
			enemyLaser2D[i][j] = new LaserEnemyShip(-3000,-3000,enemyLaserSpeed);
			}
	 }
		//*/
		

		// This loop creates all the enemies for round 1
		for(int i = 0; i < enemies.length; i ++) {
		
		enemies[i] = new EnemyShip(i*250+25,50,"green1");
		
		if(i>5) {
			enemies[i] = new EnemyShip((i-5)* 260 -120,210,"blue2");

		}
		if (i==8) {
			enemies[i] = new EnemyShip((i-5)* 260 -120,210,"red3");

		}
			
		}
		   //=======================================================================================
//TODO
		
	
		
		//This loop creates enemies for round 3
		if (Spaceship.enemyDeathCount==22) {
			//Enter code for level 3 here
			
		}
		
		   //=======================================================================================

		
		//ENEMYLASERARR
		enemyLasersArr =  new LaserEnemyShip[enemies.length];
		
		// Testing enemy lasers
		/**
				for(int i = 0; i < enemyLasers.length; i ++) {
					enemyLasersArr[i] = enemyLasers;
					
					new LaserEnemyShip(-3000,-3000,5);
				}
				*/
		
		
		// This loop creates all the enemies
//				for(int i = 1; i < 4; i ++) {
//				enemies[i] = new EnemyShip(i*250+150,250,"black2");
//				}
		
		// This loop creates circle bullets
//		for(int i = 0; i < circleBullet.length; i++) {
//			circleBullet[i] = new Circle(-30000,-30000, 5, 30);
//
//		}
		
		
		
		super.init();
	}
	
	//=======================================================================================
	
	public void inGameLoop()
	{		
		
		//Drawing lines around spaceship that move with the spaceship
		//TODO: simplify the code below
		if(true){
				
			if(pressing[UP])     {spaceship.moveUp();
			
			if (current%3==0) {
				ss1l1.moveUp();
				ss1l2.moveUp();
				ss1l3.moveUp();}
			
			else if (current%3==1) {
				
				ss2l1.moveUp();
				ss2l2.moveUp();
			    ss2l3.moveUp();}
			
			else if (current%3==2) {
				ss3l1.moveUp();
				ss3l2.moveUp();
				ss3l3.moveUp();}}
			
			//=======================================================================================


		if(pressing[DN])     {spaceship.moveDown();
			
			if (current%3==0) {
			//if(pressing[DN])     {
				ss1l1.moveDown();
			    ss1l2.moveDown();
			    ss1l3.moveDown();}
			
			else if (current%3==1) {
				//if(pressing[DN])     {
					ss2l1.moveDown();
				    ss2l2.moveDown();
				    ss2l3.moveDown();}
			
			else if (current%3==2) {
				//if(pressing[DN])     {
					 ss3l1.moveDown();
				     ss3l2.moveDown();
				     ss3l3.moveDown();}}

			//=======================================================================================

		if(pressing[LT])     {spaceship.moveLeft();
			
			if (current%3==0) {

				//if(pressing[LT]){
				ss1l1.moveLeft();
				ss1l2.moveLeft();
				ss1l3.moveLeft();
				 }
			
			else if (current%3==1) {

				// if(pressing[LT])     {
					 ss2l1.moveLeft();	 					   
					 ss2l2.moveLeft(); 					   
					 ss2l3.moveLeft();}
			
			else if (current%3==2) {

			// if(pressing[LT])     {
				 ss3l1.moveLeft();
			     ss3l2.moveLeft();
			     ss3l3.moveLeft();}}
			//=======================================================================================			
		if(pressing[RT])     {spaceship.moveRight();
			
			if (current%3==0) {
				// if(pressing[RT])     {
					 ss1l1.moveRight();
					 ss1l2.moveRight();
					 ss1l3.moveRight();}
			
			else if (current%3==1) {
				 //if(pressing[RT])     {
					 ss2l1.moveRight();
					 ss2l2.moveRight();
					 ss2l3.moveRight();}
			
			else if (current%3==2) {
			//if(pressing[RT])     {
				ss3l1.moveRight();
			    ss3l2.moveRight();
			    ss3l3.moveRight();}}
			//=======================================================================================
			//this assigns the lines to the specific ship type
			if (current%3==0) {
				ssAl1=ss1l1;	
		 		ssAl2=ss1l2;
				ssAl3=ss1l3;	
			}
			else if (current%3==1) {
				ssAl1=ss2l1;	
		 		ssAl2=ss2l2;
				ssAl3=ss2l3;	
			}
			else if (current%3==2) {
				ssAl1=ss3l1;	
		 		ssAl2=ss3l2;
				ssAl3=ss3l3;	
			}
			
			//=======================================================================================

			if(pressing[SPACE])  {spaceship.shoot(lasers);}		

			//=======================================================================================

			// Loop makes enemies shoot
			for(int i = 0; i < enemies.length; i ++) {
				
			//if(enemies[i].isAlive) {enemies[i].shoot(enemyLasers);} //see line 68
			if(enemies[0].isAlive)  {enemies[0].shoot(enemyLasers, spaceship);}
			if(enemies[1].isAlive)  {enemies[1].shoot(enemyLasers1, spaceship);}
			if(enemies[2].isAlive)  {enemies[2].shoot(enemyLasers2, spaceship);}
			if(enemies[3].isAlive)  {enemies[3].shoot(enemyLasers3, spaceship);}
			if(enemies[4].isAlive)  {enemies[4].shoot(enemyLasers4, spaceship);}
			if(enemies[5].isAlive)  {enemies[5].shoot(enemyLasers5, spaceship);}
			if(enemies[6].isAlive)  {enemies[6].shoot(enemyLasers6, spaceship);}
			if(enemies[7].isAlive)  {enemies[7].shoot(enemyLasers7, spaceship);}
			if(enemies[8].isAlive)  {enemies[8].shoot(enemyLasers8, spaceship);}
			if(enemies[9].isAlive)  {enemies[9].shoot(enemyLasers9, spaceship);}
			if(enemies[10].isAlive) {enemies[10].shoot(enemyLasers10, spaceship);}
			}
			
			/*
			 for (int i=0;i<rowi++){
			if (enemies[i].isAlive)  {enemies[i].shoot(enemyLaser2D);}
			}
			*/
			//=======================================================================================

		}	
		
		
		
		// Loop updates the lasers
		for(int i = 0; i < lasers.length; i++) {
			
			// If the laser was shot, place it on top of spaceship
			if(lasers[i].isShooting) {
				lasers[i].isShooting = true;
			}
			
			// If laser went off screen, reset its location
			if(lasers[i].wentOffScreen()) {
				lasers[i].isShooting = false;
				lasers[i].x = -20000;
				lasers[i].y = -20000;
			}
			
			/*
			// Checking if laser hit UFO
			if(lasers[i].withinRange(ufo)  && ufo.isAlive)    lasers[i].hit(ufo);
			if(lasers[i].withinRange(ufo2) && ufo2.isAlive)   lasers[i].hit(ufo2);
			if(lasers[i].withinRange(ufo3) && ufo3.isAlive)   lasers[i].hit(ufo3);
			if(lasers[i].withinRange(ufo4) && ufo4.isAlive)   lasers[i].hit(ufo4);
			if(lasers[i].withinRange(ufo5) && ufo5.isAlive)   lasers[i].hit(ufo5);
			*/
			
		//Checking if laser hit enemy ship
			for(int j = 0; j < enemies.length; j ++) {
				EnemyShip enemy = enemies[j];
				if(lasers[i].withinRange(enemy) && enemy.isAlive)    lasers[i].hit(enemy);
			}
			
		lasers[i].move();
	}
		
		   //=======================================================================================

		for(int i = 0; i < enemyLasers.length; i++) {

		// If the enemy laser was shot, place it under enemy ship
		if(enemyLasers[i].isShooting) {
		enemyLasers[i].shoot();}
	
		if(enemyLasers1[i].isShooting) {
		enemyLasers1[i].shoot();}
		
		if(enemyLasers2[i].isShooting) {
		enemyLasers2[i].shoot();}
		
		if(enemyLasers3[i].isShooting) {
		enemyLasers3[i].shoot();}
		
		if(enemyLasers4[i].isShooting) {
		enemyLasers4[i].shoot();}
		
		if(enemyLasers5[i].isShooting) {
		enemyLasers5[i].shoot();}
		
		if(enemyLasers6[i].isShooting) {
		enemyLasers6[i].shoot();}
		
		if(enemyLasers7[i].isShooting) {
		enemyLasers7[i].shoot();}
		
		if(enemyLasers8[i].isShooting) {
		enemyLasers8[i].shoot();}
		
		if(enemyLasers9[i].isShooting) {
		enemyLasers9[i].shoot();}
		
		if(enemyLasers10[i].isShooting) {
		enemyLasers10[i].shoot();}
		
		/*//replaces code above (30 lines)
	  	int rows = 11;	
	  	int cols = 30;
	  		for (int i=0;i<=rows;i++){
	  			for(int j = 0; j <= cols; j++){
	  			if (enemyLaser2D[i][j].isShooting){
	  			enemyLaser2D[i][j].shoot();}
	  			}
	  		}
	 */
		
		
		
		
		// If enemy laser went off screen, reset its location
		if(enemyLasers[i].wentOffScreen()) {
		enemyLasers[i].isShooting = false;
		enemyLasers[i].x = -30000;
		enemyLasers[i].y = -30000;
		}

		// Checking if laser hit spaceship
		if(enemyLasers[i].withinRange(spaceship)  && spaceship.isAlive)  enemyLasers[i].hit(spaceship);
		if(enemyLasers1[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers1[i].hit(spaceship);
		if(enemyLasers2[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers2[i].hit(spaceship);
		if(enemyLasers3[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers3[i].hit(spaceship);
		if(enemyLasers4[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers4[i].hit(spaceship);
		if(enemyLasers5[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers5[i].hit(spaceship);
		if(enemyLasers6[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers6[i].hit(spaceship);
		if(enemyLasers7[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers7[i].hit(spaceship);
		if(enemyLasers8[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers8[i].hit(spaceship);
		if(enemyLasers9[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers9[i].hit(spaceship);
		if(enemyLasers10[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers10[i].hit(spaceship);
		}
		//replaces code above
		/*
		 for (int i=0;i<=rows;i++){
	  			for(int j = 0; j <= cols; j++){
	  		    if (enemyLaser2D[i][j].withinRange(spaceship)  && spaceship.isAlive)  enemyLaser2D[i][j].hit(spaceship);

	  			}
	  		}
		 
		 */
		//This loop creates enemies for round 2
		if (Spaceship.enemyDeathCount>=11) {
						
			//draw enemies out of screen and make them alive again
			for(int i =0;i<enemies.length;i++) {
				enemies[i].x=-30000;
				enemies[i].y=-30000;
			}
			
			
			if(Objects.isNull(lastEnemyKilled)) {lastEnemyKilled = Calendar.getInstance().getTimeInMillis();}
			

			long currentTime = Calendar.getInstance().getTimeInMillis();
			System.out.println("GameEngine 513 Current time"+currentTime);

			
			long difference = Math.abs(currentTime - lastEnemyKilled);
			
			// coolDownTime 250 = 1/4th of a second
			long coolDownTime = 3000;
			
			
			if (difference>=3000) { //FIXME We need to spawn enemy ships 3 seconds after defeating the previous level
				lastEnemyKilled = Calendar.getInstance().getTimeInMillis();
				System.out.println("GameEngine 524 last enemy killed time"+lastEnemyKilled);


			//Reseting enemy spaceships, setting them to isAlive, and resetting their health
			for(int i =0;i<enemies.length;i++) {

				enemies[i].isAlive=true;
				enemies[i].health=100;
				
				enemies[i].x = i*250+25;
				enemies[i].y = 50;
			
				
				if(i>5) {
					enemies[i].x = (i-5)* 260 -120;
					enemies[i].y = 210;

				}

				
				
				
			}
						}
			
			Spaceship.enemyDeathCount=0;
			
			//Enter code for level 2 here
			//reset all laser arrays
			//draw ships for level2 iff deathcount>=11 and <=21
			//need to make 2d array for 35 enemy ships between all three levels
			
	
		}
		
		
		
		
		
	}					
	
	//=======================================================================================

	public void paint(Graphics g) {
		
		// Draws background several times to make sure it covers the screen
		for(int i = 0; i < 7; i ++) {
			
			for(int j = 0; j < 11; j++) {
				g.drawImage(background, i * 256, j * 256, null);
			}
			
		}
		
		// Draws the spaceship
		if (spaceship.isAlive) { //uncomment this later
		    spaceship.draw(g);
		
		}
		
		/*
		// Draws the UFO's if they are alive
		if(ufo.isAlive)   ufo.draw(g);
		if(ufo2.isAlive)  ufo2.draw(g);
		if(ufo3.isAlive)  ufo3.draw(g);
		if(ufo4.isAlive)  ufo4.draw(g);
		if(ufo5.isAlive)  ufo5.draw(g);
		
		*/
		
		// Draws enemy ships
		for(int i = 0; i < enemies.length; i ++) {
		if(enemies[i].isAlive) enemies[i].draw(g);
		}
		
		// Draws each laser
		//AI
		
		
		for(int i = 0; i < lasers.length; i ++) {
			lasers[i].draw(g);
		}
		
		// Draws each enemy ship laser
			
		for(int i = 0; i < enemyLasers.length; i++) {
		enemyLasers [i].draw(g);
		enemyLasers1[i].draw(g);
		enemyLasers2[i].draw(g);
		enemyLasers3[i].draw(g);
		enemyLasers4[i].draw(g);
		enemyLasers5[i].draw(g);
		enemyLasers6[i].draw(g);
		enemyLasers7[i].draw(g);
		enemyLasers8[i].draw(g);
		enemyLasers9[i].draw(g);
	    enemyLasers10[i].draw(g);
		}
		/*/
		00 01 02 03 04 05
		10 11 12 13 14 15
		20 21 22 23 24 25
		30 31 32 33 34 35 
		40 41 42 43 44 45
		50 51 52 53 54 55
		//*/
		
		//arr[rows][cols] means you have row arrays and each of those arrays are of size col
		/*
		 * 
		 * 
		 * this loop draws all enemy lasers using a 2D array (it replaces block of code above)
		 * -----------------------------------------
		 * int rows = 11;
		 * int cols = 30;
		 * for(int i=0;i<=rows;i++){
		 * 		for(int j = 0; j <= cols; j++){
		 * 		enemyLaser2D[i][j].draw(g);
		 * 		}
		 * }
		 * 
		 */
		
		
		
		//collision detection: Draws 3 lines above each ship depending on ship type
		
		g.setColor(Color.RED);
		
		//drawing enemy ship lines for all three ships, replacing the 15 lines of code above
		ssAl1.draw(g);
		ssAl2.draw(g);		
		ssAl3.draw(g);
		
	
    //=======================================================================================

		
		
 	}
	
	//=======================================================================================

}

