package otherClasses;
//
//public class CircleBulletTracker extends Circle {
//	
//	double x;
//	double y;
//	double speed;	
//	double r;
//	
//	public void CircleBulletTracker(double x, double y, double r, double speed)
//	{
//	
//		this.x  = x;
//		this.y  = y;
//
//		this.r  = r; 
//		
//		this.speed  = speed;
//		
//
//	}
//	//attaching a circle to the bullet
//		double lSpeed = LaserEnemyShip.speed;
//		Circle bulletTracker = new Circle(-30,-30, 2, lSpeed);
//		
//
//		
//		//updates the x and y values of the circle bulletTracker to make it move along with the EnemyLaser
//		//This method runs every time the LaserEnemyShip
//		double bulletTrackerx,bulletTrackery;
//		public void circleUpdate() {
//			bulletTrackerx=LaserEnemyShip.x;
//			bulletTrackery=LaserEnemyShip.y;
//
//		}
//
//}
