package otherClasses;
//
//
//
//
////V13 GameF20
//import java.awt.*;
//import java.awt.event.*;
//
//import java.util.*;
//
//public class GameF20 extends GameApplet
//{
//   //------------------------------------------------------------------------//
//	
////	Soldier    soldier    = new Soldier(100, 100, Soldier.DOWN);
////	BattleLord battlelord = new BattleLord(200, 500, BattleLord.LEFT);
//	Spaceship spaceship = new Spaceship( 540, 450, Spaceship.UP);
//	
//	Circle c        = new Circle(400, 100, 30, 90);
//	
//	BadCircle[] bc  = new BadCircle[3];
//	
//	Circle[] bullet = new Circle[400];
//		
//	Line[] L        = new Line[3];
//		
////	Random rnd = new Random(System.currentTimeMillis());
//
//   //------------------------------------------------------------------------//
//	
//	public void init()
//	{
//		for(int i = 0; i < bullet.length; i++)
//		{
//			bullet[i] = new Circle(-1000, -1000, 3, 0);
//			
//			bullet[i].setAcceleration(0, Circle.GRAVITY);
//		}
//			
//				
//		for(int i = 0; i < bc.length; i++)
//		{	
//			bc[i] = new BadCircle(650*i + 100 , 850, 30, 0);
//		   //bc[i].setAcceleration(0, Circle.GRAVITY);
//		}
//
//		double[][] v = 
//		{
//		   {1500, 880,    0, 880},
//		   {1450,   0, 1450, 900},
//		   {  50, 900,   50,   0},
//		};
//
//		for(int i = 0; i < v.length; i++)
//		{
//	   	L[i] = new Line(v[i][0], v[i][1], v[i][2], v[i][3]);
//		}
//		
//		super.init();
//	}
//	
//	//------------------------------------------------------------------------//
//	
//	public void inGameLoop()
//	{		
//		if(c.alive)
//		{
//			if(pressing[UP])    c.goForward(5);
//			if(pressing[DN])    c.goBackward(3);
//			if(pressing[LT])    c.turnLeft(3);
//			if(pressing[RT])    c.turnRight(3);
//			if(pressing[SPACE]) c.launch(bullet);				
//		}	
//
//		for(int i = 0; i < bc.length; i++)
//		{
//		   if(bc[i].alive)
//	   	{
//		      bc[i].turnToward(c);
//		      
//			   bc[i].launch(bullet);
//	   	}
//		}
//		
//		for(int i = 0; i < bullet.length; i++)
//		{
//			bullet[i].move();
//
//			if(bullet[i].overlaps(c))    c.alive = false;
//
//			for(int j = 0; j < bc.length; j++)
//		   {
//			   if(bullet[i].overlaps(bc[j]))    bc[j].alive = false;
//		   }
//		}
//			
//	
///*
//		   
//		for(int i = 0; i < bc.length; i++)
//		{	
//			if(bc[i].overlaps(c))
//			{	
//				bc[i].pushes(c);
//			}
//		}
//			
//		for(int i = 0; i < bc.length-1; i++)
//		{	
//			for(int j = i + 1; j < bc.length; j++ )
//			{
//		      if(bc[i].overlaps(bc[j]))
//		      {
//		      	bc[i].pushes(bc[j]);
//		      	bc[i].bounceOff(bc[j]);
//		      }
//			}
//		}
//
//		for(int j = 0; j < L.length; j++)
//		{
//			if(c.overlaps(L[j]))
//			{
//				c.isPushedBackBy(L[j]);				
//			}
//		}
//
//		for(int i = 0; i < bc.length; i++)
//		{
//			for(int j = 0; j < L.length; j++)
//			{
//				if(bc[i].overlaps(L[j]))
//				{
//					bc[i].isPushedBackBy(L[j]);
//					bc[i].bounceOff(L[j]);
//				}				
//			}
//		}
////*/
//		   
///*		
//		
//		if(pressing[UP])  battlelord.moveUp(7);
//		if(pressing[DN])  battlelord.moveDown(7);
//		if(pressing[LT])  battlelord.moveLeft(7);
//		if(pressing[RT])  battlelord.moveRight(7);		
////*/			
//		
///*		
//		if(pressing[UP])    soldier.moveUp(5);
//		if(pressing[DN])    soldier.moveDown(5);
//		if(pressing[LT])    soldier.moveLeft(5);
//		if(pressing[RT])    soldier.moveRight(5);		
//		if(pressing[SPACE]) soldier.shoot(bullet);		
////*/		
//		
//		if(pressing[UP])    spaceship.moveUp(5);
//		if(pressing[DN])    spaceship.moveDown(5);
//		if(pressing[LT])    spaceship.moveLeft(5);
//		if(pressing[RT])    spaceship.moveRight(5);		
//		//if(pressing[SPACE]) spaceship.launch(bullet);
//	}					
//	
//	//------------------------------------------------------------------------//
//
//	public void paint(Graphics g)
//	{		
//		g.setColor(Color.BLACK);
//		
//		//soldier.draw(g);
//		//battlelord.draw(g);
//		spaceship.draw(g);
//		
//		for(int i = 0; i < bc.length; i++)
//		{
//			if(bc[i].alive)   bc[i].draw(g);
//		}
//		
//		if(c.alive)
//		{
//			g.setColor(Color.RED);
//			c.draw(g);
//			g.setColor(Color.BLACK);
//		}
//		
//		for(int i = 0; i < bullet.length; i++)
//		{
//   		bullet[i].draw(g);
//		}
//		
//		
//		for(int i = 0; i < L.length; i++)
//		{
//   		L[i].draw(g);
//		}
// 	}
//	
//   //------------------------------------------------------------------------//
//
//	public void mousePressed(MouseEvent e)
//	{
//		mx = e.getX();
//		my = e.getY();
//		
//
//		for(int i = 0; i < L.length; i++)
//		
//			L[i].grabbedAt(mx, my);
//		
//		
//		for(int i = 0; i < bc.length; i++)
//			
//			bc[i].grabbedAt(mx, my);
//	}
//	
//	//------------------------------------------------------------------------//
//
//	public void mouseDragged(MouseEvent e)
//	{
//		int nx = e.getX();		
//		int ny = e.getY();
//		
//		int dx = nx - mx;
//		int dy = ny - my;
//				
//		mx = nx;
//		my = ny;
//				
//		for(int i = 0; i < L.length; i++)
//			
//			L[i].draggedBy(dx, dy);
//		
//		for(int i = 0; i < bc.length; i++)
//		{	
//			if(bc[i].held)
//			{	
//				bc[i].moveBy(dx, dy);
//				
////				bc[i].ay = 0;
//			}
//		}
//	}
//	
//	//------------------------------------------------------------------------//
//	
//	public void mouseReleased(MouseEvent e)
//	{
//		for(int i = 0; i < L.length; i++)
//			
//		   L[i].released();
//
//		for(int i = 0; i < L.length; i++)
//		{
//			
//		   bc[i].released();
//		   
////		   bc[i].ay = 0.7;
//		}
//	}
//	
//	//------------------------------------------------------------------------//
//
//}
