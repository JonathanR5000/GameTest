import java.awt.*;
import java.awt.event.*;

import java.util.*;

import javax.swing.ImageIcon;

public class GameEngine extends GameApplet{
	
	// Preparing the background image
	String backgroundPath = "purple.png";
	Image background = Toolkit.getDefaultToolkit().getImage(backgroundPath);
	
	// Player object
	Spaceship spaceship = new Spaceship(700, 700, "blue3");
		
	//collision detection variables
	int ssh = spaceship.height;
	int ssw = spaceship.width;
	double ssx = spaceship.x;
	double ssy = spaceship.y;
	
	
	
	
	
	//if (Spaceship.name = )
	int current = spaceship.currentShip;
	
	//3 lines for space ship 1
		Line ss1l1 = new Line(ssx,ssy+0.7*ssh,ssx+(ssw/2)-8 ,ssy);
		Line ss1l2 = new Line(ssx+(ssw/2)-8,ssy, ssx+(ssw/2)+8,ssy );
		Line ss1l3 = new Line(ssx+(ssw/2)+8 ,ssy,ssx+ssw, ssy+0.7*ssh);
		//======================================================================================
	
	
	//3 lines for space ship 2
	Line ss2l1 = new Line(ssx,ssy+0.6*ssh,ssx+(ssw/2)-5 ,ssy);
	Line ss2l2 = new Line(ssx+(ssw/2)-5,ssy, ssx+(ssw/2)+15,ssy );
	Line ss2l3 = new Line(ssx+(ssw/2)+15 ,ssy,ssx+1.1*ssw, ssy+0.6*ssh);
	//======================================================================================
	//3 lines for space ship 3
	
	Line ss3l1 = new Line(ssx,ssy+0.8*ssh,ssx+(ssw/2)-5 ,ssy);
	Line ss3l2 = new Line(ssx+(ssw/2)-5,ssy, ssx+(ssw/2)+5,ssy );
	Line ss3l3 = new Line(ssx+(ssw/2)+5 ,ssy,ssx+ssw, ssy+0.8*ssh);

	
	
	//======================================================================================

	//ENEMY ammunition
	LaserEnemyShip[] enemyLasersArr; 
	
	
	
	
	
	
	
	/* 
	/ Enemy objects
	UFO ufo = new UFO(300, 200, "blue");
	UFO ufo2 = new UFO(600, 100, "yellow");
	UFO ufo3 = new UFO(0, 300, "green");
	UFO ufo4 = new UFO(800, 200, "red");
	UFO ufo5 = new UFO(1100, 100, "blue");
	*/
	
	EnemyShip[] enemies = new EnemyShip[11];

	//Ammunition
	Laser[] lasers = new Laser[20];
	LaserEnemyShip[] enemyLasers = new LaserEnemyShip[30];
	LaserEnemyShip[] enemyLasers1 = new LaserEnemyShip[30];
	LaserEnemyShip[] enemyLasers2 = new LaserEnemyShip[30];
	LaserEnemyShip[] enemyLasers3 = new LaserEnemyShip[30];
	LaserEnemyShip[] enemyLasers4 = new LaserEnemyShip[30];
	LaserEnemyShip[] enemyLasers5 = new LaserEnemyShip[30];
	LaserEnemyShip[] enemyLasers6 = new LaserEnemyShip[30];
	LaserEnemyShip[] enemyLasers7 = new LaserEnemyShip[30];
	LaserEnemyShip[] enemyLasers8 = new LaserEnemyShip[30];
	LaserEnemyShip[] enemyLasers9 = new LaserEnemyShip[30];
	LaserEnemyShip[] enemyLasers10 = new LaserEnemyShip[30];
	//LaserEnemyShip[] enemyLasers11 = new LaserEnemyShip[30];


	//2d array
	//LaserEnemyShip [][] enemyLaser = new LaserEnemyShip[enemies.length][30];


	
	//need to delete this circle Array
	Circle [] circleBullet = new Circle [100];


	   //=======================================================================================

	
   //=======================================================================================
	
	public void init() {
		
		// The loop creates all of the lasers
		for(int i = 0; i < lasers.length; i++) {
			lasers[i] = new Laser(-20000, -20000, 5);
		}
		
		
		// This loop creates the enemy lasers
		for(int i = 0; i < enemyLasers.length; i++) {
			enemyLasers[i]  = new LaserEnemyShip(-30000, -30000, 6);
			
			enemyLasers1[i] = new LaserEnemyShip(-30000, -30000, 6);
			enemyLasers2[i] = new LaserEnemyShip(-30000, -30000, 6);
			enemyLasers3[i] = new LaserEnemyShip(-30000, -30000, 6);
			enemyLasers4[i] = new LaserEnemyShip(-30000, -30000, 6);
			enemyLasers5[i] = new LaserEnemyShip(-30000, -30000, 6);
			enemyLasers6[i] = new LaserEnemyShip(-30000, -30000, 6);
			enemyLasers7[i] = new LaserEnemyShip(-30000, -30000, 6);
			enemyLasers8[i] = new LaserEnemyShip(-30000, -30000, 6);
			enemyLasers9[i] = new LaserEnemyShip(-30000, -30000, 6);
			enemyLasers10[i] = new LaserEnemyShip(-30000, -30000, 6);
			//enemyLasers11[i] = new LaserEnemyShip(-30000, -30000, 6);
			



		
			/*
			for (int j=0; j<enemyLaser[i].length; j++) {
				enemyLaser[i][j]=new LaserEnemyShip(-30000,-30000,6);
		}
		*/
		
		}
		
		

		// This loop creates all the enemies
		for(int i = 0; i < enemies.length; i ++) {
		
		enemies[i] = new EnemyShip(i*250+25,50,"black2");
		
		if(i>5) {
			enemies[i] = new EnemyShip((i-5)* 260 -120,210,"black2");

		}
			
		}
		
		//ENEMYLASERARR
		enemyLasersArr =  new LaserEnemyShip[enemies.length];
		
		// Testing enemy lasers
		/**
				for(int i = 0; i < enemyLasers.length; i ++) {
					enemyLasersArr[i] = enemyLasers;
					
					new LaserEnemyShip(-3000,-3000,5);
				}
				*/
		
		
		// This loop creates all the enemies
//				for(int i = 1; i < 4; i ++) {
//				enemies[i] = new EnemyShip(i*250+150,250,"black2");
//				}
		
		// This loop creates circle bullets
		for(int i = 0; i < circleBullet.length; i++) {
			circleBullet[i] = new Circle(-30000,-30000, 5, 30);

		}
		
		
		
		super.init();
	}
	
	//=======================================================================================
	
	public void inGameLoop()
	{		
		
		//Drawing lines around spaceship that move with the spaceship
		if(true){
			if(pressing[UP])     {spaceship.moveUp();}
			
			if (current==0 || current==3 || current==6 || current==9) {
		    if(pressing[UP])     {ss1l1.moveUp();}
			 if(pressing[UP])     {ss1l2.moveUp();}
			 if(pressing[UP])     {ss1l3.moveUp();}}
			
			if (current==1 || current==4 || current==7 || current==10) {
				if(pressing[UP]) {   
				
				ss2l1.moveUp();
				ss2l2.moveUp();
			    ss2l3.moveUp();}}
			
			if (current==2 || current==5 || current==8 || current==11) {
				if(pressing[UP])     {ss3l1.moveUp();}
				 if(pressing[UP])     {ss3l2.moveUp();}
				 if(pressing[UP])     {ss3l3.moveUp();}}
			
			//=======================================================================================


			if(pressing[DN])     {spaceship.moveDown();}
			
			if (current==0 || current==3 || current==6 || current==9) {
			if(pressing[DN])     {ss1l1.moveDown();}
			 if(pressing[DN])     {ss1l2.moveDown();}
			 if(pressing[DN])     {ss1l3.moveDown();}}
			
			if (current==1 || current==4 || current==7 || current==10) {
				if(pressing[DN])     {ss2l1.moveDown();}
				 if(pressing[DN])     {ss2l2.moveDown();}
				 if(pressing[DN])     {ss2l3.moveDown();}}
			
			if (current==2 || current==5 || current==8 || current==11) {
				if(pressing[DN])     {ss3l1.moveDown();}
				 if(pressing[DN])     {ss3l2.moveDown();}
				 if(pressing[DN])     {ss3l3.moveDown();}}

			//=======================================================================================

			if(pressing[LT])     {spaceship.moveLeft();}
			
			if (current==0 || current==3 || current==6 || current==9) {

				if(pressing[LT])     
				{
				ss1l1.moveLeft();
				ss1l2.moveLeft();
				ss1l3.moveLeft();
				 }}
			
			if (current==1 || current==4 || current==7 || current==10) {

				if(pressing[LT])     {ss2l1.moveLeft();}
				 if(pressing[LT])     {ss2l2.moveLeft();}
				 if(pressing[LT])     {ss2l3.moveLeft();}}
			
			if (current==2 || current==5 || current==8 || current==11) {

			if(pressing[LT])     {ss3l1.moveLeft();}
			 if(pressing[LT])     {ss3l2.moveLeft();}
			 if(pressing[LT])     {ss3l3.moveLeft();}}
			//=======================================================================================

			
			if(pressing[RT])     {spaceship.moveRight();}
			
			if (current==0 || current==3 || current==6 || current==9) {
				if(pressing[RT])     {ss1l1.moveRight();}
				 if(pressing[RT])     {ss1l2.moveRight();}
				 if(pressing[RT])     {ss1l3.moveRight();}}
			
			if (current==1 || current==4 || current==7 || current==10) {
				if(pressing[RT])     {ss2l1.moveRight();}
				 if(pressing[RT])     {ss2l2.moveRight();}
				 if(pressing[RT])     {ss2l3.moveRight();}}
			
			if (current==2 || current==5 || current==8 || current==11) {
			if(pressing[RT])     {ss3l1.moveRight();}
			 if(pressing[RT])     {ss3l2.moveRight();}
			 if(pressing[RT])     {ss3l3.moveRight();}}
			//=======================================================================================

			
			if(pressing[SPACE])  {spaceship.shoot(lasers);}		

			
			// Loop makes enemies shoot
			for(int i = 0; i < enemies.length; i ++) {
				if(enemies[i].isAlive) {enemies[i].shoot(enemyLasers);}
			
			
			if(enemies[0].isAlive) {enemies[0].shoot(enemyLasers );}
			if(enemies[1].isAlive) {enemies[1].shoot(enemyLasers1);}
			if(enemies[2].isAlive) {enemies[2].shoot(enemyLasers2);}
			if(enemies[3].isAlive) {enemies[3].shoot(enemyLasers3);}
			if(enemies[4].isAlive) {enemies[4].shoot(enemyLasers4);}
			if(enemies[5].isAlive) {enemies[5].shoot(enemyLasers5);}
			if(enemies[6].isAlive) {enemies[6].shoot(enemyLasers6);}
			if(enemies[7].isAlive) {enemies[7].shoot(enemyLasers7);}
			if(enemies[8].isAlive) {enemies[8].shoot(enemyLasers8);}
			if(enemies[9].isAlive) {enemies[9].shoot(enemyLasers9);}
			if(enemies[10].isAlive) {enemies[10].shoot(enemyLasers10);}
			//if(enemies[11].isAlive) {enemies[11].shoot(enemyLasers11);}
			}
			
			/**
			*/



		}	
		
		
		
		// Loop updates the lasers
		for(int i = 0; i < lasers.length; i++) {
			
			// If the laser was shot, place it on top of spaceship
			if(lasers[i].isShooting) {
				lasers[i].isShooting = true;
			}
			
			// If laser went off screen, reset its location
			if(lasers[i].wentOffScreen()) {
				lasers[i].isShooting = false;
				lasers[i].x = -20000;
				lasers[i].y = -20000;
			}
			
			/*
			// Checking if laser hit UFO
			if(lasers[i].withinRange(ufo)  && ufo.isAlive)    lasers[i].hit(ufo);
			if(lasers[i].withinRange(ufo2) && ufo2.isAlive)   lasers[i].hit(ufo2);
			if(lasers[i].withinRange(ufo3) && ufo3.isAlive)   lasers[i].hit(ufo3);
			if(lasers[i].withinRange(ufo4) && ufo4.isAlive)   lasers[i].hit(ufo4);
			if(lasers[i].withinRange(ufo5) && ufo5.isAlive)   lasers[i].hit(ufo5);
			*/
			
		//Checking if laser hit enemy ship
			for(int j = 0; j < enemies.length; j ++) {
				EnemyShip enemy = enemies[j];
				if(lasers[i].withinRange(enemy) && enemy.isAlive)    lasers[i].hit(enemy);
			}
			
		lasers[i].move();
		}
			
		
		// Loop updates enemy lasers
		for(int i = 0; i < enemyLasers.length; i++) {

		// If the enemy laser was shot, place it under enemy ship
		if(enemyLasers[i].isShooting) {
		enemyLasers[i].shoot();
	
		enemyLasers1[i].shoot();
		enemyLasers2[i].shoot();
		enemyLasers3[i].shoot();
		enemyLasers4[i].shoot();
		enemyLasers5[i].shoot();
		enemyLasers6[i].shoot();
		enemyLasers7[i].shoot();
		enemyLasers8[i].shoot();
		enemyLasers9[i].shoot();
		enemyLasers10[i].shoot();
		//enemyLasers11[i].shoot();
		

}

		
		//Calculation for enemyLasers1 missing
		// If enemy laser went off screen, reset its location
		if(enemyLasers[i].wentOffScreen()) {
		enemyLasers[i].isShooting = false;
		enemyLasers[i].x = -30000;
		enemyLasers[i].y = -30000;
		}

		// Checking if laser hit spaceship
		if(enemyLasers[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers[i].hit(spaceship);
		if(enemyLasers1[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers1[i].hit(spaceship);
		if(enemyLasers2[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers2[i].hit(spaceship);
		if(enemyLasers3[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers3[i].hit(spaceship);
		if(enemyLasers4[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers4[i].hit(spaceship);
		if(enemyLasers5[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers5[i].hit(spaceship);
		if(enemyLasers6[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers6[i].hit(spaceship);
		if(enemyLasers7[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers7[i].hit(spaceship);
		if(enemyLasers8[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers8[i].hit(spaceship);
		if(enemyLasers9[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers9[i].hit(spaceship);
		if(enemyLasers10[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers10[i].hit(spaceship);
		//if(enemyLasers11[i].withinRange(spaceship) && spaceship.isAlive) enemyLasers11[i].hit(spaceship);
		


		}
		
		

		//-----------------------------------
	
//	for (int i =0;i<circleBullet.length; i++) {
//		
//			     	circleBullet[i].move();
//		
//					if(circleBullet[i].overlaps(ss1l1))    spaceship.isAlive = false;
//					if(circleBullet[i].overlaps(ss1l2))    spaceship.isAlive = false;
//					if(circleBullet[i].overlaps(ss1l3))    spaceship.isAlive = false;	
//					if(circleBullet[i].overlaps(ss2l1))    spaceship.isAlive = false;
//					if(circleBullet[i].overlaps(ss2l2))    spaceship.isAlive = false;
//					if(circleBullet[i].overlaps(ss2l3))    spaceship.isAlive = false;
//					if(circleBullet[i].overlaps(ss3l1))    spaceship.isAlive = false;
//					if(circleBullet[i].overlaps(ss3l2))    spaceship.isAlive = false;
//					if(circleBullet[i].overlaps(ss3l3))    spaceship.isAlive = false;
//					
//		
//				
//		
//	}
	
	}					
	
	//=======================================================================================

	public void paint(Graphics g) {
		
		// Draws background several times to make sure it covers the screen
		for(int i = 0; i < 7; i ++) {
			
			for(int j = 0; j < 11; j++) {
				g.drawImage(background, i * 256, j * 256, null);
			}
			
		}
		
		// Draws the spaceship
		if (spaceship.isAlive) { //uncomment this later
		    spaceship.draw(g);
		
		}
		
		/*
		// Draws the UFO's if they are alive
		if(ufo.isAlive)   ufo.draw(g);
		if(ufo2.isAlive)  ufo2.draw(g);
		if(ufo3.isAlive)  ufo3.draw(g);
		if(ufo4.isAlive)  ufo4.draw(g);
		if(ufo5.isAlive)  ufo5.draw(g);
		
		*/
		
		// Draws enemy ships
		for(int i = 0; i < enemies.length; i ++) {
		if(enemies[i].isAlive) enemies[i].draw(g);
		}
		
		// Draws each laser
		for(int i = 0; i < lasers.length; i ++) {
			lasers[i].draw(g);
		}
		
		// Draws each enemy ship laser
		for(int i = 0; i < enemyLasers.length; i++) {
		enemyLasers[i].draw(g);
		
		enemyLasers1[i].draw(g);
		enemyLasers2[i].draw(g);
		enemyLasers3[i].draw(g);
		enemyLasers4[i].draw(g);
		enemyLasers5[i].draw(g);
		enemyLasers6[i].draw(g);
		enemyLasers7[i].draw(g);
		enemyLasers8[i].draw(g);
		enemyLasers9[i].draw(g);
		enemyLasers10[i].draw(g);
		//enemyLasers11[i].draw(g);
		



		}
	
		
		//collision detection: Draws 3 lines above each ship depending on ship type
		
		g.setColor(Color.RED);
		
		if (current==0 || current==3 || current==6 || current==9) {
		ss1l1.draw(g);
		ss1l2.draw(g);		
		ss1l3.draw(g);	}	
		
		else if (current==1 || current==4 || current==7 || current==10) {
			ss2l1.draw(g);
			ss2l2.draw(g);		
			ss2l3.draw(g);	}	
		
		else if (current==2 || current==5 || current==8 || current==11) {
			ss3l1.draw(g);
			ss3l2.draw(g);		
			ss3l3.draw(g);	}
		
		// Draws the circle bullets
		
//		for(int i = 0; i < circleBullet.length; i++) {
//			circleBullet[i].draw(g);
//		}

    //=======================================================================================

 	}
	
	//=======================================================================================

}

